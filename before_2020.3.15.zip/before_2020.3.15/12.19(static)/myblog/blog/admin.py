from django.contrib import admin
from .models import Article
# Register your models here.
admin.site.site_header='ZL Blog'


class ArticleAdmin(admin.ModelAdmin):
    list_display=('title','content','pub_time')
    list_filter=('pub_time',)

admin.site.register(Article,ArticleAdmin)
