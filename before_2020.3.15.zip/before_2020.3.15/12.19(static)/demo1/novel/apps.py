from django.apps import AppConfig


class NovelConfig(AppConfig):
    name = 'novel'
